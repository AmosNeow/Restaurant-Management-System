import Customer
import Manager
import Admin
import Chef


def main_menu():
    while True:
        print("Welcome to our restaurant!")
        print("-" * 12)
        x = input("Sign In=1\nSIgn Up=2\nExit=3\n(Please enter 1, 2 or 3):")
        if x == "1":
            w = input("Sign in as:\n1. Manager\n2. Admin\n3.Chef\n4.Customer\nPlease choose the number to sign in:")
            if w == "1":
                attempts = 0
                while attempts < 3:
                    flag = False
                    u = input("Enter username(0 to exit):")
                    if u == "0":
                        return main_menu()
                    p = input("Enter password:")
                    with open("Manager", "r") as t:
                        for line in t:
                            parts = line.strip().split(",")
                            if len(parts) == 6:
                                un, ew, ge, ag, em, ph = parts
                                if u == un and p == ew:
                                    flag = True
                        t.close()
                        if flag:
                            print("Login Successful.")
                            break
                        else:
                            print("Login Failed.")
                            attempts += 1
                    if attempts == 3:
                        print("Three attempts made, exiting.")
                        exit()
                while True:
                    print("-" * 30)
                    print("Manager")
                    print("1. Manage customer")
                    print("2. Menu")
                    print("3. Ingredient list")
                    print("4. Edit profile")
                    print("5. Exit")
                    print("-" * 30)
                    x = int(input("Choose from 1 - 5:"))
                    if x == 1:
                        Manager.manage_customer()
                    elif x == 2:
                        Manager.edit_menu()
                    elif x == 3:
                        Manager.ingredient_list()
                    elif x == 4:
                        Manager.edit_profile()
                    elif x == 5:
                        print("Bye Manager!")
                        break
            if w == "2":
                attempt = 0
                while attempt < 3:
                    try:
                        admin_name = input("Please enter your name:")
                        admin_password = input("Please enter your password:")
                        with open("Admin", "r") as f:
                            admin_file = f.readline().split(" ")
                            ad_name = admin_file[admin_file.index(str(admin_name))]
                            ad_pass = admin_file[admin_file.index(str(admin_password))]
                            print(f"Correct name and password.Welcome,{admin_name}")
                        Admin.main_menu()
                        break
                    except ValueError:
                        print("Invalid username and password.")
                        attempt += 1
                if attempt == 3:
                    print("Three attempts have been made, exiting.")
                    exit()

            if w == "3":
                attempts = 0
                while attempts < 3:
                    flag = False
                    r = input("Enter username :")
                    d = input("Enter password :")
                    with open("Chef", "r") as t:
                        for line in t:
                            parts = line.strip().split(",")
                            if len(parts) == 6:
                                ln, pr, ge, ag, em, ph = parts
                                if r == ln and d == pr:
                                    flag = True
                        t.close()
                        if flag:
                            print("Login Successful.")
                            break
                        else:
                            print("Login Failed.")
                            attempts += 1
                if attempts == 3:
                    print("Three attempts have been made, exiting.")
                    exit()
                while True:
                    print(
                        f"\n{("-" * 10)}Main Menu{("-" * 10)}\n1.View orders\n2.Update orders\n3.Request ingredients")
                    print(f"4.Delete ingredients\n5.Update profile\n6.View monthly sales\n7.Leave")
                    answer = input(f"Please select option:")
                    if answer == "1":
                        Chef.view_order()
                    elif answer == "2":
                        Chef.update_status()
                    elif answer == "3":
                        Chef.add_ingredient()
                    elif answer == "4":
                        Chef.delete_ingredients()
                    elif answer == "5":
                        Chef.edit_chef_profile()
                    elif answer == "6":
                        Chef.calc_total()
                    elif answer == "7":
                        print("All done.")
                        break
                    else:
                        print("Invalid choice.")
            if w == "4":
                attempts = 0
                while attempts < 3:
                    while True:
                        flag = False
                        e = input("Enter username :")
                        if e == "0":
                            return main_menu()
                        c = input("Enter password :")
                        with open("Customer", "r") as f:
                            for line in f:
                                parts = line.strip().split(",")
                                if len(parts) == 6:
                                    tl, pc, ge, ag, em, ph = parts
                                    if e == tl and c == pc:
                                        flag = True
                            f.close()
                            if flag:
                                print("Login Successful")
                                break
                            else:
                                print("Login Failed")
                                attempts += 1
                        if attempts == 3:
                            print("Three attempts have been made, exiting.")
                            exit()
                    while True:
                        print("\n----- Customer Page -----")
                        print("1. Order Food, Modify Order and Pay")
                        print("2. View Order Status")
                        print("3. Send Feedback")
                        print("4. Update Profile")
                        print("5. Exit")
                        choice = input("Choose an option: ")
                        match choice:
                            case '1':
                                Customer.take_order_modify_pay()
                            case "2":
                                Customer.order_status()
                            case '3':
                                Customer.send_feedback()
                            case '4':
                                Customer.update_cus_profile()
                            case '5':
                                break
                    break

        elif x == "2":
            f = open("Customer", "a")
            for i in range(1):
                un = input(f"Please enter username:")
                pw = input(f"Please enter password:")
                f.write(f"{un},{pw}\n")
            f.close()
            print(f"Record added.")
        elif x == "3":
            print("Thanks for coming!")
            exit()

        else:
            print("Invalid answer.")


main_menu()

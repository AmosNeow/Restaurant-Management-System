import time


def staff():
    try:
       with open("Manager", "r") as f:
           ManagerProfileLine = []
           for line in f:
               lines = f'{line}'
               ManagerProfileLine.append(lines)
       with open("chef", "r") as f:
           ChefProfileLine = []
           for line in f:
               lines = f'\n{line}'
               ChefProfileLine.append(lines)
       with open("StaffInformation.txt", "w") as SI_txt:
           SI_txt.writelines(ManagerProfileLine)
       with open("StaffInformation.txt", "a") as SI_txt:
           SI_txt.writelines(ChefProfileLine)
       print(f"{"-"*40}\n"
             f"\tManage Staff Information\n"
             f"{"-"*40}\n"
             f"1.View Staff Information\n"
             f"2.Update Staff Information\n"
             f"3.Delete Staff Information\n"
             f"4.Return to Main Menu")
       StaffChoice = int(input("Enter number for your choice:"))
       match StaffChoice:
           case 1:
            view_staff()
            time.sleep(2)
            return staff()
           case 2:
            update_staff()
            time.sleep(2)
            return staff()
           case 3:
            delete_staff()
            time.sleep(2)
            return staff()
           case 4:
            return main_menu()
           case _:
            print("Invalid option.Please try again!")
            return staff()
    except Exception:
            print("System Error. Try again.")
            staff()


def view_staff():
    print(f"{"-" * 40}\n"
          f"\tStaff Information\n"
          f"{"-" * 40}\n")
    with open("StaffInformation.txt", "r") as SI:
        for line1 in SI:
            print(line1)


def profile():
    nu = input("Please enter your new username:")
    np = input("Please enter your new password:")
    ge = input("Please enter your gender:")
    ag = int(input("Please enter your age:"))
    gm = input("Please enter your gmail:")
    ph = input("Please enter your phone number:")
    with open('Admin', 'w') as f:
        f.write(f"{nu} {np} {ge} {ag} {gm} {ph}")
    print("File updated successfully.")


def view_feedback():
    with open("customer_feedback.txt", "r") as f:
        for i in f:
            print(i)


def sale_report():
    f = open("monthly_sales.txt", "r")
    print(f.read())


def update_staff():
    update_staff = input("Enter new record:")
    print("1.Chef\n2.Manager")
    identity = input("Enter identity of that person:")
    result = False
    if identity == '1':
        with open("Chef", "a") as f:
            f.write(update_staff+'\n')
            result = True
    elif identity == '2':
        with open("Manager", "a") as f:
            f.write(update_staff+'\n')
            result = True
    if result:
        print("Profile Update Successfully.")
    else:
        print("Profile Update Unsuccessfully.")


def delete_staff():
    delete_staff = input("Enter what you want delete:")
    print("1.Chef\n2.Manager")
    delete_id = input("Enter identity of that person:")
    SF_line = []
    delete_staff1 = f'{delete_staff}\n'
    if delete_id == '1':
        with open("Chef", "r") as file:
            for line in file:
                if delete_staff1 == line:
                    SF_line.append(line.replace(delete_staff1, ''))
                else:
                    SF_line.append(line)
        with open("Chef", "w") as file:
            file.writelines(SF_line)
        print("File Delete Successfully.")
    elif delete_id == '2':
        with open("Manager", "r") as file:
            for line in file:
                if delete_staff1 == line:
                    SF_line.append(line.replace(delete_staff1, ' '))
                else:
                    SF_line.append(line)
        with open("Manager", "w") as file:
            file.writelines(SF_line)
            print("File Delete Successfully.")


def main_menu():
    while True:
        print(f"{"-" * 40}\n\tMain Menu\n{"-" * 40}\n1.Manage Staff Information\n2.View Sales report")
        print("3.View feedback\n4.Update profile\n5.Exit")
        choice = int(input("Enter number for your choice:"))
        if choice == 1:
            staff()
            return main_menu()
        elif choice == 2:
            sale_report()
            return main_menu()
        elif choice == 3:
            view_feedback()
            return main_menu()
        elif choice == 4:
            profile()
            return main_menu()
        elif choice == 5:
            print("Goodbye!")
            break
        else:
            print("Invalid option.Please try again!")

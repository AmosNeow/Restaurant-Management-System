def edit_chef_profile():
    print("Which one do you want to change:\n1.Username\n2.Password\n3.Gender")
    print("4.Age\n5.Gmail\n6.Phone number")
    int(input("Enter your choice:"))
    y = input("Please enter your current answer in the profile:")
    u = input("Please enter your new answer:")
    with open('Chef', 'r') as file:
        lines = file.readlines()
    updated_lines = []
    for line in lines:
        columns = line.strip().split(",")
        if y in columns:
            index = columns.index(y)
            columns[index] = u
            updated_lines.append(",".join(columns) + "\n")
    with open('Chef', 'w') as file:
        file.writelines(updated_lines)
    print("File updated successfully.")


def view_order():
    f = open("order.json", "r")
    print(f.read())


def update_status():
    while True:
        with open("order_status", "r") as f:
            lines = f.readlines()
        with open("order_status", "a") as f:
            for line in lines:
                print(line)
                status = input("Order status:\n1.Change to Completed\n2.Change to In progress\n"
                               "3.Save changes and exit\nEnter your choice:")
                if status == "1":
                    with open('order_status', 'r') as file:
                        lines = file.readlines()
                    updated_lines = []
                    for status_line in lines:
                        if "In progress" in status_line:
                            updated_lines.append(status_line.replace("In progress", "Completed"))
                        else:
                            updated_lines.append(status_line)
                    with open('order_status', 'w') as file:
                        file.writelines(updated_lines)
                    print("Status update successful.")
                elif status == "2":
                    with open('order_status', 'r') as file:
                        lines = file.readlines()
                    updated_lines = []
                    for status_line in lines:
                        if "Completed" in status_line:
                            updated_lines.append(status_line.replace("Completed", "In progress"))
                        else:
                            updated_lines.append(status_line)
                    with open('order_status', 'w') as file:
                        file.writelines(updated_lines)
                    print("Status update successful.")
                elif status == "3":
                    break
                else:
                    print("Invalid option.")
            f.close()
            break


i_list = []


def add_ingredient():
    while True:
        print(f"\n{("-" * 10)}Add ingredient{("-" * 10)}\n1.Rice\n2.Mee\n3.Flour\n4.Chicken\n5.Lamb\n6.Egg\n7.Done")
        ans = input(f"Please select your ingredients:")
        f = open("ingredients.txt", "a")
        if ans == "1":
            f.write("Rice\n")
            i_list.append("Rice")
        elif ans == "2":
            f.write("Mee\n")
            i_list.append("Mee")
        elif ans == "3":
            f.write("Flour\n")
            i_list.append("Flour")
        elif ans == "4":
            f.write("Chicken\n")
            i_list.append("Chicken")
        elif ans == "5":
            f.write("Lamb\n")
            i_list.append("Lamb")
        elif ans == "6":
            f.write("Egg\n")
            i_list.append("Egg")
        elif ans == "7":
            break
        else:
            print("--Invalid option--")
        f.close()

    f = open("ingredients.txt", "r")
    count = 0
    print("----------End list----------")
    for line in f:
        line = line.rstrip()
        count = count + 1
        print(line)
    print("Total ingredients:", count)
    f.close()


def delete_ingredients():
    while True:
        try:
            print(f"\n{("-" * 10)}Delete ingredient{("-" * 10)}")
            ans2 = input("1.Rice\n2.Mee\n3.Flour\n4.Chicken\n5.Lamb\n6.Egg\n7.Done\nWhich to delete:")
            open("ingredients.txt", "r")
            print("Before:", i_list)
            if ans2 == "1":
                i_list.remove("Rice")
            elif ans2 == "2":
                i_list.remove("Mee")
            elif ans2 == "3":
                i_list.remove("Flour")
            elif ans2 == "4":
                i_list.remove("Chicken")
            elif ans2 == "5":
                i_list.remove("Lamb")
            elif ans2 == "6":
                i_list.remove("Egg")
            elif ans2 == "7":
                break
            else:
                print("--Invalid option--")
            print("After:", i_list)
        except ValueError:
            print("--Invalid option--")

    with open("ingredients.txt", "w")as file:
        for ingredients in i_list:
            file.writelines(ingredients+"\n")
    print("----------End list----------")

    f = open("ingredients.txt", "r")
    count = 0
    for line in f:
        line.rstrip()
        count = count + 1
    for ingredients in i_list:
        print(ingredients)
    print("Total ingredients:", count)
    f.close()


def calc_total():
    f = open("Sales", "r")
    total = 0
    for lines in f:
        n = float(lines)
        total += n
    print("----------\nTotal Sales: RM", total)
    f.close()

    f = open("monthly_sales.txt", "a")
    f.write(f"Total Monthly Sales: RM{total}\n")
    f.close()

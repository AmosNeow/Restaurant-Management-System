import json
menu = []
file = open("menu", "r")
file_content = file.readlines()

for i in file_content:
    new_i = i.strip().split(",")
    menu.append(new_i)


def order_status():
    while True:
        f = open("order_status", "r")
        print(f.read())
        f.close()
        g = input("Enter 0 to exit:")
        if g == "0":
            break
        else:
            print("Invalid answer.")


def display_menu():
    print("Food Menu:")
    f = open("menu", "r")
    print(f.read())


def save_order(order, filename='order.json'):
    with open(filename, 'w') as fil_file:
        json.dump(order, fil_file, indent=4)
    with open("order_status", "w") as f:
        f.write(str(order))
        f.write(", In progress")


def take_order_modify_pay():
    display_menu()
    order = []
    total_price = 0
    while True:
        try:
            c = int(input("Enter the number of the food item you want to order (0 to finish): "))
            if c == 0:
                break
            elif c < 0 or c > 10:
                print("Invalid choice. Please select a valid menu item.")
            else:
                for u in menu:
                    if str(c) == u[0]:
                        new_list = u[0], u[2], float(u[3])
                        order.append(new_list)
                        print(f"You have added {u[2]} to your order.")
                        total_price += float(u[3])
                        print("The total price:", total_price)

        except ValueError:
            (print("Please enter a valid number."))

    # Save the order if there are items in it
    if order:
        save_order(order)
        print("Your order has been saved.")
        print("\nYou have ordered:")
        for m in order:
            print(f"{m[1]} - RM{m[2]}")
        print(f"Total Price: RM{total_price:.2f}")
    else:
        print("No items were ordered.")

    with open('order.json', 'r') as or_file:
        order = json.load(or_file)
    while True:
        print("-" * 12)
        print("\nCurrent Order:")
        for idx, m in enumerate(order):
            print(f"{idx + 1}. {m[1]} - RM{m[2]:.2f}")
        print(f"Total Price: RM{total_price:.2f}")

        print("\nOptions:")
        print("1. Add Food Item")
        print("2. Delete Food Item")
        print("3. Save Changes and Go Back")

        d = int(input("Choose an option: "))

        if d == 1:
            while True:
                try:
                    item_choice = (input("Enter the number of the food item you want to add (press 0 to end): "))
                    if not item_choice.isdigit():
                        raise ValueError("Invalid input. Please enter a valid number.")
                    item_choice = int(item_choice)
                    if item_choice == 0:
                        break
                    if item_choice < 0 or item_choice > 10:
                        print("Invalid choice. Please select a valid menu item.")
                    for u in menu:
                        if str(item_choice) in u[0]:
                            new_order = u[0], u[2], float(u[3])
                            order.append(new_order)
                            total_price += float(u[3])
                            print(f"You have added {u[2]} to your order.")

                    save_order(order)
                except ValueError as ve:
                    print(ve)

        elif d == 2:
            while True:
                print("\nCurrent Order:")
                for idx, m in enumerate(order):
                    print(f"{idx + 1}. {m[1]} - RM{m[2]:.2f}")
                print(f"Total Price: RM{total_price:.2f}")

                if not order:
                    print("Your order is currently empty.")
                    continue

                try:
                    delete_choice = int(
                        input("Enter the number of the food item you want to delete(0 to end): "))
                    if delete_choice == 0:
                        break
                    if 1 <= delete_choice <= len(order):
                        removed_item = order.pop(delete_choice - 1)
                        total_price -= removed_item[2]
                        print(f"You have removed {removed_item[1]} from your order.")
                        save_order(order)
                    else:
                        print("Invalid choice. Please select a valid item number.")
                except ValueError:
                    print("Please enter a valid number.")

        elif d == 3:
            save_order(order)
            print("Your changes have been saved.")
            break

    try:
        with open('order.json', 'r') as or_file:
            order = json.load(or_file)
    except FileNotFoundError:
        print("No existing orders.")
        return
    while True:
        print("\nCurrent Order:")
        for idx, m in enumerate(order):
            print(f"{idx + 1}. {m[1]} - RM{m[2]:.2f}")
        print(f"Total Price: RM{total_price:.2f}")
        z = input("\n1.Pay using cash\n2.Pay using credit card\n3.Pay via e-wallet \nPlease enter your choice:")
        if z == "1":
            print("Order received.\nPlease pay at the counter after you have finish your meal.")
        elif z == "2":
            print("Order received.\nPlease pay at the counter after you have finish your meal.")
        elif z == "3":
            print("Order received.\nThe QR code is at the counter.")
            print("Please pay at the counter after you have finish your meal.")
        else:
            print("Invalid option.")
        with open('total_price.txt', 'w') as to_file:
            to_file.write(f"Total Price: RM{total_price:.2f}\n")
        sales = []
        sales.append(total_price)
        with open('sales', 'a') as sa_file:
            for price in sales:
                sa_file.write(f"{price:.2f}\n")
            break


def send_feedback():
    feedback = input("Write your feedback: ")
    with open("customer_feedback.txt", "a") as f:
        f.write(f"{feedback}\n")
    print("Feedback sent successfully!")


def update_cus_profile():
    while True:
        print("Which one do you want to change:\n1.Username\n2.Password\n3.Gender")
        print("4.Age\n5.Gmail\n6.Phone number")
        int(input("Enter your choice:"))
        y = input("Please enter current information in the profile:")
        u = input("Please enter your new information:")
        with open('Customer', 'r') as Cus_file:
            lines = Cus_file.readlines()
        updated_lines = []
        found = False
        for line in lines:
            columns = line.strip().split(",")
            if y in columns:
                index = columns.index(y)
                columns[index] = u
                updated_lines.append(",".join(columns) + "\n")
                found = True
            else:
                updated_lines.append(line)

        if found:
            with open('Customer', 'w') as Cus_file:
                Cus_file.writelines(updated_lines)
            print("File updated successfully.")
            break
        else:
            print("File update unsuccessful. Please try again.")

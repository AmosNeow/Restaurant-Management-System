menu = []
file = open("menu", "r")
file_content = file.readlines()

for i in file_content:
    new_i = i.strip().split(",")
    menu.append(new_i)

Customer_profile = []
file = open("Customer", "r")
file_content = file.readlines()

for i in file_content:
    Pro_i = i.strip().split(",")
    Customer_profile.append(Pro_i)


def manage_customer():
    o = input("1.Delete customer profile\n2. Customer order\nEnter your choice:")
    if o == "1":
        while True:
            print("-" * 12)
            f = open("Customer", "r")
            print(f.read())
            print("-" * 12)
            delete_profile = input("Enter the username you want to delete(0 to exit): ")
            if delete_profile == "0":
                break
            for j in Customer_profile:
                try:
                    if delete_profile == j[0]:
                        with open("Customer", 'r') as Pro_file:
                            lines = Pro_file.readlines()
                        with open("Customer", 'w') as Cu_file:
                            for line in lines:
                                columns = line.strip().split(",")
                                if columns[0] != j[0]:
                                    Cu_file.write(line)
                        print(f"You have removed {j[0]} from customer account.")
                        break
                except ValueError:
                    print("Please do not enter digit number.")

    elif o == "2":
        while True:
            try:
                import json
                with open('order.json', 'r') as or_file:
                    order = json.load(or_file)
                print(json.dumps(order, indent=4))
                g = int(input("Enter 0 to exit:"))
                if g == 0:
                    break
            except ValueError:
                print("Invalid input.\n")
    else:
        print("Invalid option.")


def edit_menu():
    while True:
        print("-" * 12)
        f = open("menu", "r")
        print(f.read())
        print("-" * 12)
        print("1. Edit menu")
        print("2. Add menu record")
        print("3. Delete menu record")
        print("4. Save changes and exit")
        x = input("Enter your answer (1,2,3,4):")
        if x == "1":
            print("-" * 12)
            f = open("menu", "r")
            print(f.read())
            print("-" * 12)
            while True:
                g = input("Please enter what you want to edit:")
                z = input("Please enter your changes:")
                with open('menu', 'r') as me_file:
                    lines = me_file.readlines()
                updated_lines = []
                found = False
                for line in lines:
                    columns = line.strip().split(",")
                    if g in columns:
                        index = columns.index(g)
                        columns[index] = z
                        updated_lines.append(line.replace(g, z))
                        found = True
                    else:
                        updated_lines.append(line)

                if found:
                    with open('menu', 'w') as me_file:
                        me_file.writelines(updated_lines)
                    print("File updated successfully.")
                    break
                else:
                    print("File update unsuccessful. Please try again.")

        elif x == "2":
            print("-" * 12)
            f = open("menu", "r")
            print(f.read())
            print("-" * 12)
            f = open("menu", "a")
            item_id = int(input("Please enter the number of the food:"))
            item_categories = input("Please enter the categories of the food:")
            item = input("Please enter the food:")
            item_price = input(f"Please enter the price of the food(enter 2 decimal point):")
            change = [str(item_id),item_categories,item,str(item_price)]
            menu.append(change)
            f.close()
            with open("menu", "a") as f:
                f.write(",".join(change) + "\n")

        elif x == "3":
            while True:
                print("-" * 12)
                f = open("menu", "r")
                print(f.read())
                print("-" * 12)
                try:
                    delete_choice = int(input("Enter the number of the food item you want to delete(0 to end): "))
                    if delete_choice == 0:
                        break
                    for h in menu:
                        if delete_choice == int(h[0]):
                            with open("menu", 'r') as me_file:
                                lines = me_file.readlines()
                            with open("menu", 'w') as no_file:
                                for line in lines:
                                    columns = line.strip().split(",")
                                    if columns[0] != h[0]:
                                        no_file.write(line)
                            print(f"You have removed {h[2]} from your order.")
                    if delete_choice <= -1 or delete_choice > 10:
                        print("Invalid choice.")
                except ValueError:
                    print("Please enter a valid number.")
        elif x == "4":
            print("Your changes have been recorded.")
            break
        else:
            print("Invalid answer.")


def ingredient_list():
    while True:
        f = open("ingredients.txt", "r")
        print(f.read())
        d = input("Enter 0 to exit:")
        if d == "0":
            break
        else:
            print("Invalid answer.")


def edit_profile():
    while True:
        print("Which one do you want to change:\n1.Username\n2.Password\n3.Gender")
        print("4.Age\n5.Gmail\n6.Phone number")
        int(input("Enter your choice:"))
        g = input("Please enter current your current before changing(0 to exit):")
        if g == "0":
            break
        z = input("Please enter your new change:")
        with open('Manager', 'r') as on_file:
            lines = on_file.readlines()
        updated_lines = []
        found = False
        for line in lines:
            columns = line.strip().split(",")
            if g in columns:
                index = columns.index(g)
                columns[index] = z
                updated_lines.append(",".join(columns) + "\n")
                found = True
            else:
                updated_lines.append(line)

        if found:
            with open('Manager', 'w') as Man_file:
                Man_file.writelines(updated_lines)
            print("File updated successfully.")
            break
        else:
            print("File update unsuccessful. Please try again.")
